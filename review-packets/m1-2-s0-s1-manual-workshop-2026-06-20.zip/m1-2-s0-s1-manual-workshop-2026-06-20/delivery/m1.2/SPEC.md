# M1.2 Specification - Grounded Tactical Query Workshop

## Product Outcome

A soccer expert can describe a positional process, inspect Hermes's interpretation, execute the bound query plan, review real moments and non-matches, label good and bad results, approve an explicit revision, and save a new immutable experimental recipe version.

## Boundary Decision

M1.2 makes Hermes a first-class client of the M1.1 deterministic runtime. It does not invent a separate agent analytics path.

M1.2 begins only after M1.1 is accepted. If M1.1 fails, the problem is architectural. If M1.2 fails, the deterministic runtime remains valuable and the problem is language interpretation or interaction design.

M1.2 proves the workshop loop and bounded compilation. It does not prove broad soccer-language understanding; M4 remains the broader reliability and tactical lexicon hardening gate.

## Current Work Order

The externally approved M1.2 opening cut is:

```text
S0  Freeze the safe capability and tool boundary.
S1  Build the manual reference workshop before Hermes.
S2  Add Hermes drafting and clarification only after S1 works manually.
S3  Add feedback-driven revision diffs and immutable recipe versions.
```

The first implementation stop is after S0 and S1. S2 and S3 remain out of
scope until the manual typed-plan -> execution -> traces -> coordinate replay
-> feedback loop receives review.

## Scope

M1.2 includes:

- Hermes/tool-mediated drafting of `DraftQueryPlan` objects;
- recipe search across approved, user-saved, experimental, and deprecated recipes;
- deterministic validation and binding before execution;
- visible interpretation and confirmation before execution;
- structured feedback labels;
- known-miss inspection against a supplied `EvaluationTarget`;
- agent-proposed revisions using AST-aware semantic diffs;
- result deltas: added, removed, retained, feedback effects, and held-out warnings;
- immutable query versioning;
- deliberately simple local persistence;
- experimental recipe saving;
- a thin visual workshop loop sufficient to prove describe, draft, run, review, revise, save.

## Non-Goals

M1.2 excludes:

- new primitive implementation;
- new runtime operators;
- bypassing M1.1 binder or executor;
- arbitrary Python, SQL, filesystem editing, generated code, or primitive mutation;
- threshold auto-tuning without explicit user approval;
- complete raw-match coordinate dumps into model context;
- model training from feedback;
- automatic promotion of experimental plans to approved recipes;
- semantic vector search or embeddings;
- polished M3/M5-grade workbench design;
- production persistence, auth, cloud deployment, or match video.

## Hermes Tool Boundary

During S0/S1, the exposed tool surface is intentionally limited to:

```text
list_capabilities
describe_capability
validate_query_plan
execute_query_plan
inspect_result
inspect_non_match
retrieve_replay_window
compare_query_versions
record_feedback
save_experimental_recipe
```

Hermes drafting tools are deferred to S2 and must be added only after this
manual surface is reviewed.

Hermes may not use:

```text
arbitrary Python execution
unrestricted SQL
filesystem editing
primitive implementation access
result-row mutation
threshold auto-tuning
complete raw-match coordinate dumps
```

Hermes has access to the complete dataset through scoped tools, not by loading coordinates into model context.

`retrieve_tracking_window` returns:

- artifact or replay-window ID;
- summary metadata;
- available derived signals;
- links usable by the interface.

It must not place hundreds or thousands of coordinate rows into the model context. The browser or local workbench can retrieve replay frames directly.

## Runtime Decision Process

Hermes follows this order:

1. Search approved recipes.
2. Search user-saved recipes.
3. Compose an experimental plan only if all needed primitives/relations exist.
4. Report a capability gap if a required primitive or relation is unavailable.

Unsupported concepts must not be silently approximated. A disclosed approximation can be proposed, but it cannot execute as if it were exact.

Hermes may not fabricate explanations for non-matches. It must present the engine result, including `NO_COMPATIBLE_ANCHOR` when applicable.

## M1.2 S0 Capability Guard

The Hermes-visible capability context is stricter than the internal catalog. S0 must expose only operator/source combinations with positive proof coverage.

Until broader collection semantics are intentionally designed and tested:

- Hermes may use `exists` and `count_at_least` only for declared `anchor_evaluations` coverage outputs;
- Hermes must not bind `exists` or `count_at_least` directly to raw relation episode collections;
- Hermes must not use generic Boolean `EpisodeSet` counting as if it were anchor-relative;
- rejected or hidden combinations must appear as explicit capability gaps, not silent approximations.

The S0 verifier must prove that the Hermes-facing capability context enforces this safe subset even if the internal runtime contains broader compatibility paths.

## Human Visual Inspection Boundary

M1.2 requires human visual inspection, but not polished UI. The manual reference workshop in S1 must let a user open each result and relevant non-match in a coordinate replay window.

Structural traces answer why the engine matched. Coordinate replay lets the user decide whether the spatial sequence captures the intended football concept.

Final typography, transitions, guided mode, and visual polish remain outside M1.2.

## Feedback Labels

Structured feedback labels:

```text
MATCHES_INTENT
NEAR_MATCH
FALSE_POSITIVE
KNOWN_MISS
UNUSABLE_DATA
```

Feedback records contain:

- query version;
- moment ID or supplied `EvaluationTarget`;
- label;
- reason code;
- optional analyst note;
- reviewer;
- timestamp.

Feedback cannot delete results. It can only inform a proposed new query version.

## Revision Requirements

Every material revision requires user confirmation and produces a new immutable query version.

The interface must show:

- semantic plan diff;
- raw JSON diff in a developer drawer;
- prior result count;
- revised result count;
- full-corpus added results;
- full-corpus removed results;
- full-corpus retained results;
- effect on prior positive labels;
- effect on prior false positives;
- effect on known misses;
- held-out warning when labelled examples improve but held-out examples degrade.

Use AST-aware diffs. Do not rely only on textual JSON diffs.

Example semantic diff:

```text
Support definition changed

Before:
Any teammate within 12 metres

After:
Inside or progressive geometric corridor
persisting at least 0.4 seconds
```

All result deltas must be computed by the deterministic engine, not by Hermes.

## Persistence

M1.2 needs immutable recipe versions, not a platform database.

A local content-addressed file store or SQLite database is sufficient.

Every saved version preserves:

- parent version;
- draft plan;
- bound plan;
- semantic diff;
- query hash;
- execution IDs;
- feedback references;
- creator;
- timestamp.

Saved versions may never be overwritten. Previous versions remain executable.

## Recipe States

```text
APPROVED
Reviewed and regression-tested.

USER_SAVED
Saved intentionally by an analyst or workspace.

EXPERIMENTAL
Agent-authored composition not independently validated.

DEPRECATED
Retained for history but no longer recommended.
```

Experimental recipes cannot promote themselves.

## Quantitative Agent Evaluation

Before M1.2 begins, freeze a test corpus containing at least:

```text
20 supported requests
10 ambiguous requests
10 unsupported requests
10 revision instructions
```

Initial acceptance:

- 100 percent schema-valid plan or explicit refusal;
- at least 90 percent correct capability/recipe selection for supported requests;
- at least 90 percent appropriate clarification for ambiguous requests;
- 100 percent explicit capability-gap handling for unsupported primitives;
- zero unconfirmed material revisions;
- zero invented primitive or operator IDs.

M4 can later harden broader language reliability with a larger corpus.

## Internal Gates

### S0 - Capability and Tool Boundary

Hard acceptance:

- generated capability context exists at `generated/capability-context.json`;
- the exposed tool list is exactly the S0/S1 list above;
- `exists` and `count_at_least` are agent-visible only for declared
  `anchor_evaluations`;
- host-owned complexity ceilings are visible and enforced by validation;
- unsupported concepts fail as capability gaps;
- manual plan validation works without Hermes.

### S1 - Manual Reference Workshop

Hard acceptance:

- approved M1 recipe and experimental corridor recipe both execute manually;
- returned results expose ranked rows, predicate traces, requested evidence,
  and coordinate replay windows;
- known-timestamp inspection explains non-matches with failed/unknown
  predicates;
- feedback labels `MATCHES_INTENT`, `NEAR_MATCH`, `FALSE_POSITIVE`,
  `KNOWN_MISS`, and `UNUSABLE_DATA` are recorded through a schema-valid tool;
- an experimental recipe can be saved as an immutable content-addressed
  version;
- a plain local replay workshop artifact is generated;
- no Hermes, model calls, canned prompts, or hardcoded result moments are used.

### Gate A - Tool Boundary and Capability Context

Hard acceptance:

- Hermes tool surface is bounded to the approved tools;
- no filesystem editing, code execution, SQL, primitive mutation, result-row mutation, threshold auto-tuning, or raw coordinate dumps are available;
- generated capability context includes primitives, relations, operators, recipe states, limitations, and supported evidence fields;
- unsupported concepts produce capability-gap responses;
- manual plan entry remains usable without Hermes.

### Gate B - Draft, Bind, Confirm, Execute

Hard acceptance:

- Hermes produces only schema-valid draft plans or explicit refusals;
- all plans are validated/bound by the deterministic compiler before execution;
- user sees the interpretation before execution;
- every assistant execution records original text, draft plan, bound plan, confirmation, result IDs, hashes, scope, and provenance;
- the same bound plan produces identical results whether invoked manually or by Hermes;
- manual plan inspector remains usable when Hermes is unavailable.

### Gate C - Feedback and Non-Match Inspection

Hard acceptance:

- analyst can label returned moments with structured labels;
- analyst can provide an `EvaluationTarget`;
- engine evaluates that target against the bound plan and returns failed/unknown predicates or `NO_COMPATIBLE_ANCHOR`;
- feedback persists across restart;
- feedback remains associated with the query version on which it was given;
- feedback cannot silently alter results.

### Gate D - Revision and Versioning

Hard acceptance:

- Hermes proposes explicit revisions using available primitives/relations only;
- semantic and raw diffs are visible;
- full-corpus added, removed, and retained result sets are inspectable;
- previous versions remain reproducible and executable;
- old recipe versions remain immutable;
- material revisions require confirmation;
- revisions that improve labelled examples but degrade held-out examples produce an overfitting warning;
- saved recipes are immutable versions.

### Gate E - Workshop Thin Slice

Hard acceptance:

- user can complete the full describe, draft, run, review, revise, save loop;
- every result opens in real coordinate replay;
- predicate values displayed in the UI equal evidence values;
- no featured result is hardcoded;
- no canned assistant responses or hardcoded demo prompts are present.

### Gate F - Agent Evaluation

Hard acceptance:

- frozen M1.2 request corpus exists;
- supported, ambiguous, unsupported, and revision-instruction tests meet the quantitative thresholds;
- hidden paraphrases are included;
- all tool calls are logged;
- zero invented primitive or operator IDs occur.

## Required Artifacts

```text
delivery/m1.2/SPEC.md
delivery/m1.2/status.yaml
generated/capability-context.json
artifacts/m1.2/gate-s0-verification-report.json
artifacts/m1.2/gate-s1-verification-report.json
artifacts/m1.2/workshop/index.html
artifacts/m1.2/workshop/manual-workshop-data.json
artifacts/m1.2/workshop/feedback-records.jsonl
artifacts/m1.2/workshop/recipes/*.json
artifacts/m1.2/agent-evaluation-corpus.json
artifacts/m1.2/agent-evaluation-report.json
artifacts/m1.2/workshop-loop-trace.json
artifacts/m1.2/query-version-manifest.json
artifacts/m1.2/feedback-records.jsonl
artifacts/m1.2/revision-delta-report.json
artifacts/m1.2/persistence-restart-report.json
artifacts/m1.2/verification-report.json
```

## Required Commands

```bash
make m1-1-verify
make m1-2-verify
```

`make m1-2-verify` must fail if Hermes bypasses the binder, unsupported concepts are silently approximated, revisions happen without confirmation, prior versions are unreproducible, feedback is lost across restart, result deltas are model-computed, or workshop evidence is hardcoded.

## Anti-Reward-Hacking Rules

- Hermes never executes generated code.
- Hermes never mutates primitive implementations.
- Hermes never silently changes thresholds or semantics.
- Agent memory cannot change query semantics; persisted recipes and feedback are explicit and versioned.
- Unsupported concepts produce capability gaps, not nearby substitute executions.
- Experimental, user-saved, approved, and deprecated recipes remain visually distinct.
- No result is deleted to satisfy feedback.
- Known misses remain visible even when a revision still fails to find them.
- Revisions cannot claim improvement from labelled examples alone; held-out effects must be shown.
- Canned demo prompt mappings are forbidden.

## Stop Conditions

Stop and reassess if:

- Hermes succeeds only on canned prompts;
- unsupported prompts execute as approximate supported prompts;
- feedback causes hidden threshold tuning;
- query versions cannot be reproduced;
- result deltas cannot be explained;
- the workshop UI bypasses the M1.1 runtime;
- the assistant becomes necessary for manual execution;
- old recipe versions cannot be executed after a restart.
